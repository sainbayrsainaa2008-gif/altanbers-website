<?php
// api/products.php
session_start();
require_once '../config/database.php';

$db = getDB();
$result = $db->query('SELECT * FROM products WHERE is_active = 1 ORDER BY sort_order ASC');
$products = [];
while ($row = $result->fetch_assoc()) {
    $products[] = $row;
}
echo json_encode(['success' => true, 'products' => $products]);
$db->close();
