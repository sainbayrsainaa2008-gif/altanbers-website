<?php
// api/orders.php
session_start();
require_once '../config/database.php';

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'POST') {
    handleCreateOrder();
} elseif ($method === 'GET') {
    handleGetOrders();
} else {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
}

function handleCreateOrder() {
    $fullName = trim($_POST['full_name'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $serviceType = trim($_POST['service_type'] ?? '');
    $additionalInfo = trim($_POST['additional_info'] ?? '');
    $userId = $_SESSION['user_id'] ?? null;

    if (!$fullName || !$phone || !$email || !$serviceType) {
        http_response_code(400);
        echo json_encode(['error' => 'Шаардлагатай талбаруудыг бөглөнө үү']);
        return;
    }

    $filePath = null;
    if (isset($_FILES['file']) && $_FILES['file']['error'] === 0) {
        $uploadDir = '../uploads/';
        if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);
        
        $allowed = ['pdf', 'png', 'jpg', 'jpeg'];
        $ext = strtolower(pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION));
        
        if (!in_array($ext, $allowed)) {
            http_response_code(400);
            echo json_encode(['error' => 'Зөвхөн PDF, PNG, JPG файл зөвшөөрнө']);
            return;
        }
        
        if ($_FILES['file']['size'] > 10 * 1024 * 1024) {
            http_response_code(400);
            echo json_encode(['error' => 'Файлын хэмжээ 10MB-аас ихгүй байна']);
            return;
        }
        
        $fileName = uniqid() . '.' . $ext;
        move_uploaded_file($_FILES['file']['tmp_name'], $uploadDir . $fileName);
        $filePath = 'uploads/' . $fileName;
    }

    $db = getDB();
    $stmt = $db->prepare('INSERT INTO orders (user_id, full_name, phone, email, service_type, additional_info, file_path) VALUES (?, ?, ?, ?, ?, ?, ?)');
    $stmt->bind_param('issssss', $userId, $fullName, $phone, $email, $serviceType, $additionalInfo, $filePath);

    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Захиалга амжилттай илгээгдлээ!', 'order_id' => $db->insert_id]);
    } else {
        http_response_code(500);
        echo json_encode(['error' => 'Захиалга илгээхэд алдаа гарлаа']);
    }
    $db->close();
}

function handleGetOrders() {
    if (!isset($_SESSION['user_id'])) {
        http_response_code(401);
        echo json_encode(['error' => 'Нэвтрэх шаардлагатай']);
        return;
    }

    $db = getDB();
    $role = $_SESSION['user_role'] ?? 'user';
    
    if ($role === 'admin') {
        $result = $db->query('SELECT o.*, u.name as user_name FROM orders o LEFT JOIN users u ON o.user_id = u.id ORDER BY o.created_at DESC');
    } else {
        $userId = $_SESSION['user_id'];
        $stmt = $db->prepare('SELECT * FROM orders WHERE user_id = ? ORDER BY created_at DESC');
        $stmt->bind_param('i', $userId);
        $stmt->execute();
        $result = $stmt->get_result();
    }

    $orders = [];
    while ($row = $result->fetch_assoc()) {
        $orders[] = $row;
    }
    echo json_encode(['success' => true, 'orders' => $orders]);
    $db->close();
}

// Handle PUT - update order status
if ($method === 'PUT') {
    session_start();
    if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
        http_response_code(403);
        echo json_encode(['error' => 'Admin эрх шаардлагатай']);
        return;
    }
    $id = intval($_GET['id'] ?? 0);
    $data = json_decode(file_get_contents('php://input'), true);
    $status = $data['status'] ?? '';
    $allowed = ['pending','processing','completed','cancelled'];
    if (!$id || !in_array($status, $allowed)) {
        http_response_code(400);
        echo json_encode(['error' => 'Буруу өгөгдөл']);
        return;
    }
    $db = getDB();
    $stmt = $db->prepare('UPDATE orders SET status = ? WHERE id = ?');
    $stmt->bind_param('si', $status, $id);
    $stmt->execute();
    echo json_encode(['success' => true]);
    $db->close();
}
