<?php
// api/auth.php
session_start();
require_once '../config/database.php';

$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';

switch ($action) {
    case 'login':
        handleLogin();
        break;
    case 'register':
        handleRegister();
        break;
    case 'logout':
        handleLogout();
        break;
    case 'me':
        handleMe();
        break;
    default:
        echo json_encode(['error' => 'Unknown action']);
}

function handleLogin() {
    $data = json_decode(file_get_contents('php://input'), true);
    $email = trim($data['email'] ?? '');
    $password = $data['password'] ?? '';

    if (!$email || !$password) {
        http_response_code(400);
        echo json_encode(['error' => 'Имэйл болон нууц үг шаардлагатай']);
        return;
    }

    $db = getDB();
    $stmt = $db->prepare('SELECT id, name, email, password, role FROM users WHERE email = ?');
    $stmt->bind_param('s', $email);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    if (!$user || !password_verify($password, $user['password'])) {
        http_response_code(401);
        echo json_encode(['error' => 'Имэйл эсвэл нууц үг буруу байна']);
        return;
    }

    $_SESSION['user_id'] = $user['id'];
    $_SESSION['user_name'] = $user['name'];
    $_SESSION['user_email'] = $user['email'];
    $_SESSION['user_role'] = $user['role'];

    unset($user['password']);
    echo json_encode(['success' => true, 'user' => $user]);
    $db->close();
}

function handleRegister() {
    $data = json_decode(file_get_contents('php://input'), true);
    $name = trim($data['name'] ?? '');
    $email = trim($data['email'] ?? '');
    $password = $data['password'] ?? '';

    if (!$name || !$email || !$password) {
        http_response_code(400);
        echo json_encode(['error' => 'Бүх талбарыг бөглөнө үү']);
        return;
    }

    if (strlen($password) < 6) {
        http_response_code(400);
        echo json_encode(['error' => 'Нууц үг хамгийн багадаа 6 тэмдэгт байна']);
        return;
    }

    $db = getDB();
    $check = $db->prepare('SELECT id FROM users WHERE email = ?');
    $check->bind_param('s', $email);
    $check->execute();
    if ($check->get_result()->num_rows > 0) {
        http_response_code(409);
        echo json_encode(['error' => 'Энэ имэйл аль хэдийн бүртгэлтэй байна']);
        return;
    }

    $hashed = password_hash($password, PASSWORD_DEFAULT);
    $stmt = $db->prepare('INSERT INTO users (name, email, password) VALUES (?, ?, ?)');
    $stmt->bind_param('sss', $name, $email, $hashed);
    
    if ($stmt->execute()) {
        $userId = $db->insert_id;
        $_SESSION['user_id'] = $userId;
        $_SESSION['user_name'] = $name;
        $_SESSION['user_email'] = $email;
        $_SESSION['user_role'] = 'user';
        echo json_encode(['success' => true, 'user' => ['id' => $userId, 'name' => $name, 'email' => $email, 'role' => 'user']]);
    } else {
        http_response_code(500);
        echo json_encode(['error' => 'Бүртгэл амжилтгүй боллоо']);
    }
    $db->close();
}

function handleLogout() {
    session_destroy();
    echo json_encode(['success' => true]);
}

function handleMe() {
    if (!isset($_SESSION['user_id'])) {
        http_response_code(401);
        echo json_encode(['error' => 'Нэвтрээгүй байна']);
        return;
    }
    echo json_encode([
        'id' => $_SESSION['user_id'],
        'name' => $_SESSION['user_name'],
        'email' => $_SESSION['user_email'],
        'role' => $_SESSION['user_role']
    ]);
}
