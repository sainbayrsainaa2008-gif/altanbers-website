-- Altan Bers Database Schema
-- Run this in phpMyAdmin or MySQL console

CREATE DATABASE IF NOT EXISTS altanbers_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE altanbers_db;

-- Users table
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role ENUM('admin', 'user') DEFAULT 'user',
    google_id VARCHAR(100) NULL,
    facebook_id VARCHAR(100) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Products/Services table
CREATE TABLE IF NOT EXISTS products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    description TEXT,
    category VARCHAR(100),
    image_url VARCHAR(500),
    is_active BOOLEAN DEFAULT TRUE,
    sort_order INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Orders table
CREATE TABLE IF NOT EXISTS orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NULL,
    full_name VARCHAR(100) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    email VARCHAR(150) NOT NULL,
    service_type VARCHAR(100) NOT NULL,
    additional_info TEXT,
    file_path VARCHAR(500) NULL,
    status ENUM('pending', 'processing', 'completed', 'cancelled') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);

-- Password reset tokens
CREATE TABLE IF NOT EXISTS password_resets (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(150) NOT NULL,
    token VARCHAR(255) NOT NULL,
    expires_at TIMESTAMP NOT NULL,
    used BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert default admin user (password: admin123)
INSERT INTO users (name, email, password, role) VALUES
('Admin', 'admin@altanbers.mn', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin');

-- Insert sample products
INSERT INTO products (title, description, category, image_url, sort_order) VALUES
('Хэвлэл реклам', 'Нэрийн хуудас, каталог, товхимол болон бусад хэвлэмэл материал', 'print', 'https://images.unsplash.com/photo-1586953208448-b95a79798f07?w=400', 1),
('Гэрэлтүүлгтэй реклам', 'LED дэлгэц, гэрэлт самбар, неон гэрэлтүүлэг', 'light', 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=400', 2),
('Дотроосоо гэрэлтэй хаяг', 'Гэрэлтүүлгтэй үсэн хаяг, световой короб', 'sign', 'https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=400', 3),
('Дотор, гадна биет хаяг', 'Байгууллагын хаяг, үсэн хаяг, объемные буквы', 'outdoor', 'https://images.unsplash.com/photo-1508739773434-c26b3d09e071?w=400', 4),
('Бусад реклам', 'Гэрэлт самбар, урсдаг самбар, сурталчилгааны материал', 'other', 'https://images.unsplash.com/photo-1563986768494-4dee2763ff3f?w=400', 5),
('Өргөмжлөл, урилга', 'Аклын болон баярын өргөмжлөл, урилга, бусад албан бичиг', 'award', 'https://images.unsplash.com/photo-1554774853-aae0a22c8aa4?w=400', 6),
('Материал, хэрэгслийн', 'Хэвлэлийн материал болон хэрэгслийн худалдаа', 'material', 'https://images.unsplash.com/photo-1452860606245-08befc0ff44b?w=400', 7),
('Төмөр лазер зүсэлт', 'Лазер зүсэлт болон металл боловсруулалт', 'laser', 'https://images.unsplash.com/photo-1565688534245-05d6b5be184a?w=400', 8),
('Гадна хэвлэл (туг далбаа)', 'Туг, далбаа, баннер болон гадна хэвлэлийн бүтээгдэхүүн', 'flag', 'https://images.unsplash.com/photo-1529778873920-4da4926a72c2?w=400', 9),
('Байгууллагын танилцуулга', 'Мэдээллийн самбар, хүндэт самбар, корпоратив дизайн', 'corporate', 'https://images.unsplash.com/photo-1586281380349-632531db7ed4?w=400', 10);
