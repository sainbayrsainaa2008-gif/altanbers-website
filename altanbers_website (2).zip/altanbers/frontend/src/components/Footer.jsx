import { Link } from 'react-router-dom'
import { MapPin, Phone, Mail, Facebook, Instagram, Twitter, Linkedin } from 'lucide-react'
import './Footer.css'

export default function Footer() {
  return (
    <footer className="footer">
      <div className="footer-inner">
        <div className="footer-brand">
          <h3 className="footer-logo">АЛТАНБЭРС ХХК</h3>
          <p className="footer-desc">
            2005 оноос хойш хэвлэл, реклам чимэглэлийн салбарт тэргүүлэгч компани. Бид таны бизнесийг гэрэлтүүлнэ.
          </p>
        </div>

        <div className="footer-contact">
          <h4>Холбоо барих</h4>
          <ul>
            <li><MapPin size={15} /> Улаанбаатар хот, Сүхбаатар дүүрэг</li>
            <li><Phone size={15} /> +976 99123456</li>
            <li><Mail size={15} /> info@altanbers.mn</li>
          </ul>
        </div>

        <div className="footer-social">
          <h4>Биднийг дагах</h4>
          <div className="social-icons">
            <a href="#" className="social-icon"><Facebook size={18} /></a>
            <a href="#" className="social-icon"><Instagram size={18} /></a>
            <a href="#" className="social-icon"><Twitter size={18} /></a>
            <a href="#" className="social-icon"><Linkedin size={18} /></a>
          </div>
        </div>
      </div>

      <div className="footer-bottom">
        <p>© 2026 Алтанбэрс ХХК. Бүх эрх хуулиар хамгаалагдсан.</p>
        <div className="footer-bottom-links">
          <Link to="#">Нууцлалын бодлого</Link>
          <Link to="#">Үйлчилгээний нөхцөл</Link>
        </div>
      </div>
    </footer>
  )
}
