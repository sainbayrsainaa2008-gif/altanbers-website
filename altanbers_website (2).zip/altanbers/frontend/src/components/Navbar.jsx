import { useState } from 'react'
import { Link, useLocation } from 'react-router-dom'
import { useAuth } from '../AuthContext'
import { Menu, X } from 'lucide-react'
import './Navbar.css'

export default function Navbar() {
  const { user, logout } = useAuth()
  const location = useLocation()
  const [mobileOpen, setMobileOpen] = useState(false)

  const navLinks = [
    { to: '/', label: 'Нүүр' },
    { to: '/about', label: 'Бидний тухай' },
    { to: '/products', label: 'Бүтээгдэхүүн үйлчилгээ' },
    { to: '/order', label: 'Захиалга' },
    { to: '/login', label: user ? (user.name.split(' ')[0]) : 'Нэвтрэх' },
  ]

  return (
    <nav className="navbar">
      <div className="navbar-inner">
        <Link to="/" className="navbar-logo">
          <div className="logo-circle">AB</div>
          <span className="logo-text">Altan Bers</span>
        </Link>

        <ul className="navbar-links">
          {navLinks.map(link => (
            <li key={link.to}>
              <Link
                to={link.to}
                className={`nav-link ${location.pathname === link.to ? 'active' : ''}`}
                onClick={() => {
                  if (link.to === '/login' && user) return
                }}
              >
                {link.label}
              </Link>
            </li>
          ))}
          {user && (
            <li>
              <button className="nav-logout" onClick={logout}>Гарах</button>
            </li>
          )}
        </ul>

        <button className="mobile-menu-btn" onClick={() => setMobileOpen(!mobileOpen)}>
          {mobileOpen ? <X size={22} /> : <Menu size={22} />}
        </button>
      </div>

      {mobileOpen && (
        <div className="mobile-menu">
          {navLinks.map(link => (
            <Link
              key={link.to}
              to={link.to}
              className={`mobile-nav-link ${location.pathname === link.to ? 'active' : ''}`}
              onClick={() => setMobileOpen(false)}
            >
              {link.label}
            </Link>
          ))}
          {user && (
            <button className="mobile-logout" onClick={() => { logout(); setMobileOpen(false) }}>Гарах</button>
          )}
        </div>
      )}
    </nav>
  )
}
