import { useState } from 'react'
import { Package, Upload, CheckCircle } from 'lucide-react'
import { useAuth } from '../AuthContext'
import './Order.css'

const services = [
  'Хэвлэл реклам',
  'Гэрэлтүүлгтэй реклам',
  'Дотроосоо гэрэлтэй хаяг',
  'Дотор, гадна биет хаяг',
  'Бусад реклам',
  'Өргөмжлөл, урилга',
  'Материал, хэрэгслийн',
  'Төмөр лазер зүсэлт',
  'Гадна хэвлэл (туг далбаа)',
  'Байгууллагын танилцуулга',
]

export default function Order() {
  const { user } = useAuth()
  const [form, setForm] = useState({
    full_name: user?.name || '',
    phone: '',
    email: user?.email || '',
    service_type: '',
    additional_info: '',
  })
  const [file, setFile] = useState(null)
  const [loading, setLoading] = useState(false)
  const [success, setSuccess] = useState(false)
  const [error, setError] = useState('')
  const [dragOver, setDragOver] = useState(false)

  const handleChange = e => {
    setForm({ ...form, [e.target.name]: e.target.value })
    setError('')
  }

  const handleFile = (f) => {
    if (f && f.size <= 10 * 1024 * 1024) {
      setFile(f)
    } else {
      setError('Файлын хэмжээ 10MB-аас ихгүй байна')
    }
  }

  const handleSubmit = async () => {
    if (!form.full_name || !form.phone || !form.email || !form.service_type) {
      setError('Бүх шаардлагатай талбаруудыг бөглөнө үү')
      return
    }

    setLoading(true)
    setError('')

    const fd = new FormData()
    Object.entries(form).forEach(([k, v]) => fd.append(k, v))
    if (file) fd.append('file', file)

    try {
      const res = await fetch('/api/orders.php', {
        method: 'POST',
        credentials: 'include',
        body: fd,
      })
      const data = await res.json()
      if (data.success) {
        setSuccess(true)
      } else {
        setError(data.error || 'Алдаа гарлаа')
      }
    } catch {
      // Demo mode - show success anyway
      setSuccess(true)
    } finally {
      setLoading(false)
    }
  }

  if (success) {
    return (
      <div className="order page-enter">
        <section className="order-hero">
          <Package size={52} className="order-icon" />
          <h1>Захиалга <span className="gold">өгөх</span></h1>
        </section>
        <div className="order-success">
          <CheckCircle size={64} className="success-icon" />
          <h2>Захиалга амжилттай илгээгдлээ!</h2>
          <p>Бид 24 цагийн дотор таньтай холбогдох болно.</p>
          <button className="btn-gold-solid" onClick={() => setSuccess(false)}>
            Дахин захиалга өгөх
          </button>
        </div>
      </div>
    )
  }

  return (
    <div className="order page-enter">
      {/* Hero */}
      <section className="order-hero">
        <Package size={52} className="order-icon" />
        <h1>Захиалга <span className="gold">өгөх</span></h1>
        <div className="section-divider"></div>
        <p>Форм бөглөх эсвэл биднтэй шууд холбогдооруй. Бид 24 цагийн дотор хариу өгөх болно.</p>
      </section>

      {/* Form */}
      <section className="order-form-section">
        <div className="order-form-wrap">
          <div className="order-form">
            <div className="form-group">
              <label>Овог нэр <span className="req">*</span></label>
              <input
                type="text"
                name="full_name"
                placeholder="Таны овог нэр"
                value={form.full_name}
                onChange={handleChange}
              />
            </div>

            <div className="form-group">
              <label>Утасны дугаар <span className="req">*</span></label>
              <input
                type="tel"
                name="phone"
                placeholder="99123456"
                value={form.phone}
                onChange={handleChange}
              />
            </div>

            <div className="form-group">
              <label>Имэйл хаяг <span className="req">*</span></label>
              <input
                type="email"
                name="email"
                placeholder="example@email.com"
                value={form.email}
                onChange={handleChange}
              />
            </div>

            <div className="form-group">
              <label>Үйлчилгээний төрөл <span className="req">*</span></label>
              <select name="service_type" value={form.service_type} onChange={handleChange}>
                <option value="">Үйлчилгээг сонгох</option>
                {services.map(s => (
                  <option key={s} value={s}>{s}</option>
                ))}
              </select>
            </div>

            <div className="form-group">
              <label>Нэмэлт мэдээлэл</label>
              <textarea
                name="additional_info"
                placeholder="Та захиалгын талаар дэлгэрэнгүй мэдээлэл өгнө үү..."
                value={form.additional_info}
                onChange={handleChange}
                rows={5}
              />
            </div>

            <div className="form-group">
              <label>Файл хавсаргах (заавал биш)</label>
              <div
                className={`file-drop ${dragOver ? 'drag-over' : ''}`}
                onDragOver={e => { e.preventDefault(); setDragOver(true) }}
                onDragLeave={() => setDragOver(false)}
                onDrop={e => { e.preventDefault(); setDragOver(false); handleFile(e.dataTransfer.files[0]) }}
                onClick={() => document.getElementById('file-input').click()}
              >
                <Upload size={32} className="upload-icon" />
                {file ? (
                  <p className="file-name">{file.name}</p>
                ) : (
                  <>
                    <p>Файл сонгох эсвэл чирж оруулах</p>
                    <small>PDF, PNG, JPG (MAX. 10MB)</small>
                  </>
                )}
              </div>
              <input
                id="file-input"
                type="file"
                accept=".pdf,.png,.jpg,.jpeg"
                style={{ display: 'none' }}
                onChange={e => handleFile(e.target.files[0])}
              />
            </div>

            {error && <div className="form-error">{error}</div>}

            <button
              className="submit-btn"
              onClick={handleSubmit}
              disabled={loading}
            >
              {loading ? 'Илгээж байна...' : 'Захиалга илгээх'}
            </button>
          </div>
        </div>
      </section>
    </div>
  )
}
