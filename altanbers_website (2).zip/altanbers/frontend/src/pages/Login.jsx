import { useState } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import { LogIn } from 'lucide-react'
import { useAuth } from '../AuthContext'
import './Login.css'

export default function Login() {
  const { login, register } = useAuth()
  const navigate = useNavigate()
  const [tab, setTab] = useState('login')
  const [form, setForm] = useState({ name: '', email: '', password: '' })
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const handleChange = e => {
    setForm({ ...form, [e.target.name]: e.target.value })
    setError('')
  }

  const handleSubmit = async () => {
    setLoading(true)
    setError('')
    try {
      let data
      if (tab === 'login') {
        data = await login(form.email, form.password)
      } else {
        if (!form.name) { setError('Нэрийг оруулна уу'); setLoading(false); return }
        data = await register(form.name, form.email, form.password)
      }
      if (data.success) {
        navigate('/')
      } else {
        setError(data.error || 'Алдаа гарлаа')
      }
    } catch {
      // Demo: auto login
      navigate('/')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="login-page page-enter">
      <div className="login-card">
        <LogIn size={36} className="login-icon" />
        <h1>{tab === 'login' ? 'Тавтай морилно уу' : 'Бүртгүүлэх'}</h1>
        <p className="login-sub">
          {tab === 'login' ? 'Өөрийн бүртгэлдээ нэвтрэх' : 'Шинэ бүртгэл үүсгэх'}
        </p>

        <div className="login-tabs">
          <button
            className={tab === 'login' ? 'tab active' : 'tab'}
            onClick={() => { setTab('login'); setError('') }}
          >
            Нэвтрэх
          </button>
          <button
            className={tab === 'register' ? 'tab active' : 'tab'}
            onClick={() => { setTab('register'); setError('') }}
          >
            Бүртгүүлэх
          </button>
        </div>

        <div className="login-form">
          {tab === 'register' && (
            <div className="lf-group">
              <label>Нэр</label>
              <input
                type="text"
                name="name"
                placeholder="Таны нэр"
                value={form.name}
                onChange={handleChange}
              />
            </div>
          )}

          <div className="lf-group">
            <label>Имэйл хаяг</label>
            <input
              type="email"
              name="email"
              placeholder="admin@dern-support.mn"
              value={form.email}
              onChange={handleChange}
            />
          </div>

          <div className="lf-group">
            <label>Нууц үг</label>
            <input
              type="password"
              name="password"
              placeholder="••••••••"
              value={form.password}
              onChange={handleChange}
              onKeyDown={e => e.key === 'Enter' && handleSubmit()}
            />
          </div>

          {tab === 'login' && (
            <div className="forgot-row">
              <Link to="#" className="forgot-link">Нууц үгээ мартсан?</Link>
            </div>
          )}

          {error && <div className="login-error">{error}</div>}

          <button className="login-btn" onClick={handleSubmit} disabled={loading}>
            {loading ? 'Түр хүлээнэ үү...' : tab === 'login' ? 'Нэвтрэх' : 'Бүртгүүлэх'}
          </button>

          {tab === 'login' && (
            <>
              <div className="or-divider"><span>Эсвэл</span></div>
              <div className="social-logins">
                <button className="social-btn google">
                  <svg width="18" height="18" viewBox="0 0 24 24"><path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/><path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/><path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/><path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/></svg>
                  Google
                </button>
                <button className="social-btn facebook">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="#1877F2"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>
                  Facebook
                </button>
              </div>
            </>
          )}

          <p className="switch-tab">
            {tab === 'login' ? (
              <>Бүртгэл байхгүй юу? <button onClick={() => setTab('register')}>Бүртгүүлэх</button></>
            ) : (
              <>Бүртгэл байна уу? <button onClick={() => setTab('login')}>Нэвтрэх</button></>
            )}
          </p>
        </div>
      </div>
    </div>
  )
}
