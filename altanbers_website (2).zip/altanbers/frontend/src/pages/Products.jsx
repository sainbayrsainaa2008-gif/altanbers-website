import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { Package, ArrowRight } from 'lucide-react'
import './Products.css'

const fallbackProducts = [
  { id: 1, title: 'Хэвлэл реклам', description: 'Нэрийн хуудас, каталог, товхимол болон бусад хэвлэмэл материал', image_url: 'https://images.unsplash.com/photo-1586953208448-b95a79798f07?w=500&h=320&fit=crop' },
  { id: 2, title: 'Гэрэлтүүлгтэй реклам', description: 'LED дэлгэц, гэрэлт самбар, неон гэрэлтүүлэг', image_url: 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=500&h=320&fit=crop' },
  { id: 3, title: 'Дотроосоо гэрэлтэй хаяг', description: 'Гэрэлтүүлгтэй үсэн хаяг, световой короб', image_url: 'https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=500&h=320&fit=crop' },
  { id: 4, title: 'Дотор, гадна биет хаяг', description: 'Байгууллагын хаяг, үсэн хаяг, объемные буквы', image_url: 'https://images.unsplash.com/photo-1508739773434-c26b3d09e071?w=500&h=320&fit=crop' },
  { id: 5, title: 'Бусад реклам', description: 'Гэрэлт самбар, урсдаг самбар, сурталчилгааны материал', image_url: 'https://images.unsplash.com/photo-1563986768494-4dee2763ff3f?w=500&h=320&fit=crop' },
  { id: 6, title: 'Өргөмжлөл, урилга', description: 'Аклын болон баярын өргөмжлөл, урилга, бусад албан бичиг', image_url: 'https://images.unsplash.com/photo-1554774853-aae0a22c8aa4?w=500&h=320&fit=crop' },
  { id: 7, title: 'Материал, хэрэгслийн', description: 'Хэвлэлийн материал болон хэрэгслийн худалдаа', image_url: 'https://images.unsplash.com/photo-1452860606245-08befc0ff44b?w=500&h=320&fit=crop' },
  { id: 8, title: 'Төмөр лазер зүсэлт', description: 'Лазер зүсэлт болон металл боловсруулалт', image_url: 'https://images.unsplash.com/photo-1565688534245-05d6b5be184a?w=500&h=320&fit=crop' },
  { id: 9, title: 'Гадна хэвлэл (туг далбаа)', description: 'Туг, далбаа, баннер болон гадна хэвлэлийн бүтээгдэхүүн', image_url: 'https://images.unsplash.com/photo-1529778873920-4da4926a72c2?w=500&h=320&fit=crop' },
  { id: 10, title: 'Байгууллагын танилцуулга', description: 'Мэдээллийн самбар, хүндэт самбар, корпоратив дизайн', image_url: 'https://images.unsplash.com/photo-1586281380349-632531db7ed4?w=500&h=320&fit=crop' },
]

export default function Products() {
  const [products, setProducts] = useState(fallbackProducts)

  useEffect(() => {
    fetch('/api/products.php', { credentials: 'include' })
      .then(r => r.json())
      .then(data => {
        if (data.success && data.products?.length > 0) {
          setProducts(data.products)
        }
      })
      .catch(() => {})
  }, [])

  return (
    <div className="products page-enter">
      {/* Hero */}
      <section className="products-hero">
        <Package size={52} className="products-icon" />
        <h1>Бүтээгдэхүүн <span className="gold">үйлчилгээ</span></h1>
        <div className="section-divider"></div>
        <p>Хэвлэл, реклам чимэглэлийн бүх төрлийн үйлчилгээг чанартай, шуурхай хийж гүйцэтгэнэ</p>
      </section>

      {/* Products Grid */}
      <section className="products-grid-section">
        <div className="products-inner">
          <div className="products-grid">
            {products.map(product => (
              <div key={product.id} className="product-card">
                <div className="product-image">
                  <img src={product.image_url} alt={product.title} loading="lazy" />
                </div>
                <div className="product-body">
                  <h3 className="product-title">{product.title}</h3>
                  <p className="product-desc">{product.description}</p>
                  <Link to="/order" className="product-order">
                    Захиалга өгөх <ArrowRight size={14} />
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="products-cta">
        <h2>Захиалга өгөхөд бэлэн үү?</h2>
        <p>Биднэтэй хамтран ажиллаж, таны бизнесийг гэрэлтүүлээрэй</p>
        <Link to="/order" className="btn-gold">Захиалга өгөх</Link>
      </section>
    </div>
  )
}
