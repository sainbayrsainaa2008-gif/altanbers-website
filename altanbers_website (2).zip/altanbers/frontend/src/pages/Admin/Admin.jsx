import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../../AuthContext'
import { Package, Users, Clock, CheckCircle, XCircle, LogOut, ChevronDown } from 'lucide-react'
import './Admin.css'

const STATUS_LABELS = {
  pending: 'Хүлээгдэж байна',
  processing: 'Боловсруулж байна',
  completed: 'Дууссан',
  cancelled: 'Цуцлагдсан',
}

const STATUS_COLORS = {
  pending: '#D4A017',
  processing: '#3182CE',
  completed: '#38A169',
  cancelled: '#E53E3E',
}

// Demo orders for when DB is not connected
const DEMO_ORDERS = [
  { id: 1, full_name: 'Батболд Дорж', phone: '99112233', email: 'bat@mail.mn', service_type: 'Хэвлэл реклам', additional_info: 'Нэрийн хуудас 500 ширхэг', status: 'pending', created_at: '2026-05-05 09:00:00' },
  { id: 2, full_name: 'Сарнай Ганбат', phone: '88223344', email: 'sarnai@mail.mn', service_type: 'Гэрэлтүүлгтэй реклам', additional_info: 'LED самбар 2x3м', status: 'processing', created_at: '2026-05-05 10:30:00' },
  { id: 3, full_name: 'Энхбаяр Цэрэн', phone: '99334455', email: 'enkh@mail.mn', service_type: 'Өргөмжлөл, урилга', additional_info: 'Баярын урилга 200 ширхэг', status: 'completed', created_at: '2026-05-04 14:00:00' },
  { id: 4, full_name: 'Мөнхцэцэг Ням', phone: '77445566', email: 'munk@mail.mn', service_type: 'Дотроосоо гэрэлтэй хаяг', additional_info: 'Байгууллагын хаяг', status: 'pending', created_at: '2026-05-04 16:45:00' },
]

export default function Admin() {
  const { user, logout } = useAuth()
  const navigate = useNavigate()
  const [orders, setOrders] = useState(DEMO_ORDERS)
  const [activeTab, setActiveTab] = useState('all')
  const [loading, setLoading] = useState(false)
  const [openDropdown, setOpenDropdown] = useState(null)

  useEffect(() => {
    if (user && user.role !== 'admin') {
      navigate('/')
    }
    fetchOrders()
  }, [user])

  const fetchOrders = async () => {
    setLoading(true)
    try {
      const res = await fetch('/api/orders.php', { credentials: 'include' })
      const data = await res.json()
      if (data.success && data.orders?.length > 0) {
        setOrders(data.orders)
      }
    } catch {
      // use demo data
    } finally {
      setLoading(false)
    }
  }

  const updateStatus = async (orderId, newStatus) => {
    setOrders(prev => prev.map(o => o.id === orderId ? { ...o, status: newStatus } : o))
    setOpenDropdown(null)
    try {
      await fetch(`/api/orders.php?id=${orderId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ status: newStatus })
      })
    } catch {}
  }

  const filtered = activeTab === 'all' ? orders : orders.filter(o => o.status === activeTab)

  const counts = {
    all: orders.length,
    pending: orders.filter(o => o.status === 'pending').length,
    processing: orders.filter(o => o.status === 'processing').length,
    completed: orders.filter(o => o.status === 'completed').length,
    cancelled: orders.filter(o => o.status === 'cancelled').length,
  }

  return (
    <div className="admin-page">
      {/* Sidebar */}
      <aside className="admin-sidebar">
        <div className="admin-logo">
          <div className="admin-logo-circle">AB</div>
          <span>Алтан Бэрс</span>
        </div>

        <nav className="admin-nav">
          <button className="admin-nav-item active">
            <Package size={18} /> Захиалгууд
          </button>
        </nav>

        <div className="admin-sidebar-bottom">
          <div className="admin-user-info">
            <div className="admin-avatar">{user?.name?.[0] || 'A'}</div>
            <div>
              <p className="admin-user-name">{user?.name || 'Admin'}</p>
              <p className="admin-user-role">Администратор</p>
            </div>
          </div>
          <button className="admin-logout-btn" onClick={() => { logout(); navigate('/') }}>
            <LogOut size={16} /> Гарах
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="admin-main">
        <div className="admin-header">
          <h1>Захиалгын удирдлага</h1>
          <p>Нийт {orders.length} захиалга байна</p>
        </div>

        {/* Stats Cards */}
        <div className="admin-stats">
          <div className="admin-stat-card pending">
            <Clock size={24} />
            <div>
              <span className="stat-num">{counts.pending}</span>
              <span className="stat-label">Хүлээгдэж байна</span>
            </div>
          </div>
          <div className="admin-stat-card processing">
            <Package size={24} />
            <div>
              <span className="stat-num">{counts.processing}</span>
              <span className="stat-label">Боловсруулж байна</span>
            </div>
          </div>
          <div className="admin-stat-card completed">
            <CheckCircle size={24} />
            <div>
              <span className="stat-num">{counts.completed}</span>
              <span className="stat-label">Дууссан</span>
            </div>
          </div>
          <div className="admin-stat-card cancelled">
            <XCircle size={24} />
            <div>
              <span className="stat-num">{counts.cancelled}</span>
              <span className="stat-label">Цуцлагдсан</span>
            </div>
          </div>
        </div>

        {/* Filter Tabs */}
        <div className="admin-tabs">
          {['all', 'pending', 'processing', 'completed', 'cancelled'].map(tab => (
            <button
              key={tab}
              className={`admin-tab ${activeTab === tab ? 'active' : ''}`}
              onClick={() => setActiveTab(tab)}
            >
              {tab === 'all' ? 'Бүгд' : STATUS_LABELS[tab]}
              <span className="tab-count">{counts[tab]}</span>
            </button>
          ))}
        </div>

        {/* Orders Table */}
        <div className="admin-table-wrap">
          <table className="admin-table">
            <thead>
              <tr>
                <th>#</th>
                <th>Нэр</th>
                <th>Утас</th>
                <th>Имэйл</th>
                <th>Үйлчилгээ</th>
                <th>Мэдээлэл</th>
                <th>Огноо</th>
                <th>Төлөв</th>
              </tr>
            </thead>
            <tbody>
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={8} className="empty-row">Захиалга байхгүй байна</td>
                </tr>
              ) : (
                filtered.map(order => (
                  <tr key={order.id}>
                    <td className="order-id">#{order.id}</td>
                    <td className="order-name">{order.full_name}</td>
                    <td>{order.phone}</td>
                    <td className="order-email">{order.email}</td>
                    <td className="order-service">{order.service_type}</td>
                    <td className="order-info">{order.additional_info || '—'}</td>
                    <td className="order-date">
                      {new Date(order.created_at).toLocaleDateString('mn-MN')}
                    </td>
                    <td>
                      <div className="status-dropdown-wrap">
                        <button
                          className="status-badge"
                          style={{ background: STATUS_COLORS[order.status] + '22', color: STATUS_COLORS[order.status], borderColor: STATUS_COLORS[order.status] + '44' }}
                          onClick={() => setOpenDropdown(openDropdown === order.id ? null : order.id)}
                        >
                          {STATUS_LABELS[order.status]}
                          <ChevronDown size={12} />
                        </button>
                        {openDropdown === order.id && (
                          <div className="status-menu">
                            {Object.entries(STATUS_LABELS).map(([val, label]) => (
                              <button
                                key={val}
                                className={`status-option ${order.status === val ? 'active' : ''}`}
                                onClick={() => updateStatus(order.id, val)}
                              >
                                <span className="status-dot" style={{ background: STATUS_COLORS[val] }}></span>
                                {label}
                              </button>
                            ))}
                          </div>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </main>
    </div>
  )
}
