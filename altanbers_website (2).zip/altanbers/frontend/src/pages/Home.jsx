import { Link } from 'react-router-dom'
import { Printer, Award, Lightbulb, Clock, ArrowRight } from 'lucide-react'
import './Home.css'

export default function Home() {
  return (
    <div className="home page-enter">
      {/* Hero Section */}
      <section className="hero">
        <div className="hero-bg"></div>
        <div className="hero-content">
          <div className="hero-text">
            <h1 className="hero-title">
              БҮТЭЭЛЭЭР<br />
              БРЭНДЭЭ<br />
              <span className="hero-gold">ГЭРЭЛТҮҮЛ</span>
            </h1>
            <p className="hero-desc">
              Алтан Бэрс хэвлэлийн компани нь орчин үеийн тоног төхөөрөмж, мэргэжлийн баг хамт олон бид таны бизнесийг бусдаас ялгарах шийдлээр тодруулна.
            </p>
            <div className="hero-buttons">
              <Link to="/products" className="btn-primary">
                Бүтээгдэхүүн үзэх <ArrowRight size={16} />
              </Link>
              <Link to="/order" className="btn-outline">
                Захиалга өгөх
              </Link>
            </div>
          </div>
          <div className="hero-logo-circle">
            <div className="circle-logo">
              <span className="circle-ab">AB</span>
              <span className="circle-name">АЛТАН БЭРС</span>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="stats">
        <div className="stats-inner">
          <div className="stat-item">
            <Printer size={36} className="stat-icon" />
            <p>Орчин үеийн тоног төхөөрөмж</p>
          </div>
          <div className="stat-divider"></div>
          <div className="stat-item">
            <Award size={36} className="stat-icon" />
            <p>20 жил туршлагатай</p>
          </div>
          <div className="stat-divider"></div>
          <div className="stat-item">
            <Lightbulb size={36} className="stat-icon" />
            <p>Мэргэжлийн баг</p>
          </div>
          <div className="stat-divider"></div>
          <div className="stat-item">
            <Clock size={36} className="stat-icon" />
            <p>Шуурхай үйлчилгээ</p>
          </div>
        </div>
      </section>

      {/* Trusted Partner Section */}
      <section className="partner">
        <div className="partner-inner">
          <h2 className="section-title">
            Таны <span className="gold">найдвартай</span> түнш
          </h2>
          <div className="section-divider"></div>
          <p className="partner-desc">
            2005 оноос хойш Та бүхэнд хэвлэл, реклам чимэглэлийн өргөн хүрээний үйлчилгээ үзүүлж байна
          </p>
          <Link to="/about" className="btn-dark">Дэлгэрэнгүй</Link>
        </div>
      </section>
    </div>
  )
}
