import { Building2, Target, Users } from 'lucide-react'
import './About.css'

export default function About() {
  return (
    <div className="about page-enter">
      {/* Hero */}
      <section className="about-hero">
        <Building2 size={52} className="about-hero-icon" />
        <h1>Бидний <span className="gold">тухай</span></h1>
        <div className="section-divider"></div>
        <p>2005 оноос эхлэн Монгол улсын хэвлэл, реклам чимэглэлийн салбарт тэргүүлэгч</p>
      </section>

      {/* Intro */}
      <section className="about-intro">
        <div className="about-inner">
          <h2 className="about-section-title gold">Танилцуулга</h2>
          <p className="intro-text">
            <span className="gold-bold">'АЛТАНБЭРС' ХХК</span> нь хаяг, реклам чимэглэлийн анхдагч компаниудын нэг бөгөөд 2005 оноос хойш реклам чимэглэлийн чиглэлээр даган хөгжиж Та бүхний итгэлийг хүлээн, урт хугацаанд хамтран ажиллаж, туршлагатай гүйцэтгэч болсноор одоо Танд олон төрлийн бүтээгдэхүүн, үйлчилгээг санал болгож байна.
          </p>
          <p className="intro-text">
            Хамтран ажиллаж, үйлчлүүлж буй Та бүхэнд баярлалаа.
          </p>
        </div>
      </section>

      {/* Mission */}
      <section className="about-mission">
        <div className="about-inner">
          <div className="mission-box">
            <div className="mission-header">
              <Target size={28} className="gold" />
              <h3>Бүтээгдэхүүн, үйл ажиллагааны чиглэл</h3>
            </div>
            <p className="mission-sub gold">БҮХ ТӨРЛИЙН ХАЯГ, РЕКЛАМ ЧИМЭГЛЭЛИЙГ ИЖ БҮРЭН ГҮЙЦЭТГЭХ</p>
            <ul className="mission-list">
              <li>Төрийн болон төрийн бус байгууллага, бизнесийн байгууллага, хувь хүний нүүдас</li>
              <li>Өргөмжлөл, гэрэлт самбар</li>
              <li>Фото болон хулдаасан хэвлэл</li>
              <li>Байгууллагын гэрэлт болон товгор үсэн хаяг</li>
              <li>Урсдаг самбар, LED дэлгэцийг хийж, угсарч гүйцэтгэнэ</li>
              <li>Реклам чимэглэлийн материал болон дагалдах хэрэгслийн худалдаа</li>
            </ul>
          </div>
        </div>
      </section>

      {/* Team */}
      <section className="about-team">
        <div className="about-inner">
          <Users size={40} className="team-icon" />
          <h2 className="team-title">Манай баг</h2>
          <div className="section-divider"></div>
          <div className="team-image-wrap">
            <img
              src="https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=900&h=450&fit=crop"
              alt="Манай баг"
              className="team-image"
            />
            <div className="team-overlay">
              <p>Мэргэжлийн баг хамт олон таны төслийг амжилттай хэрэгжүүлнэ</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
