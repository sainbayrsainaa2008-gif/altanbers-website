import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: {
      '/api': {
        target: 'http://localhost/altanbers',
        changeOrigin: true,
        rewrite: (path) => path.replace(/^\/api/, '/backend/api')
      }
    }
  }
})
