# Алтан Бэрс ХХК - Вэбсайт

Хар дэвсгэр, алтан өнгийн design бүхий хэвлэл, реклам чимэглэлийн компанийн вэбсайт.

## Технологи

- **Frontend**: React 18 + Vite + React Router
- **Backend**: PHP 8 (XAMPP)
- **Database**: MySQL (phpMyAdmin)

## Суулгах заавар

### 1. XAMPP тохиргоо

1. XAMPP-г нэмж нээгээд Apache болон MySQL-г эхлүүлнэ
2. `C:\xampp\htdocs\` фолдерт **`altanbers`** фолдер үүсгэнэ
3. `backend` фолдерийг тэр дотор хуулна:
   ```
   C:\xampp\htdocs\altanbers\backend\
   ```

### 2. Database үүсгэх

1. Браузерт `http://localhost/phpmyadmin` руу нэвтэрнэ
2. **SQL** tab дарна
3. `backend/database.sql` файлын бүх агуулгыг хуулж буулгаад **Go** дарна
4. `altanbers_db` database болон хүснэгтүүд үүснэ

### 3. Frontend суулгах

Terminal (cmd) нээгээд:
```bash
cd frontend
npm install
npm run dev
```

Вэбсайт: `http://localhost:5173`

### 4. Admin нэвтрэх

- **Имэйл**: `admin@altanbers.mn`
- **Нууц үг**: `password`

> ⚠️ Анхны нэвтрэлтийн дараа нууц үгээ солино уу!

## Хуудасны бүтэц

| URL | Хуудас |
|-----|--------|
| `/` | Нүүр хуудас |
| `/about` | Бидний тухай |
| `/products` | Бүтээгдэхүүн & Үйлчилгээ |
| `/order` | Захиалга өгөх |
| `/login` | Нэвтрэх / Бүртгүүлэх |

## API endpoints (PHP)

| Endpoint | Method | Тайлбар |
|----------|--------|---------|
| `/api/auth.php?action=login` | POST | Нэвтрэх |
| `/api/auth.php?action=register` | POST | Бүртгүүлэх |
| `/api/auth.php?action=logout` | GET | Гарах |
| `/api/auth.php?action=me` | GET | Одоогийн хэрэглэгч |
| `/api/products.php` | GET | Бүтээгдэхүүний жагсаалт |
| `/api/orders.php` | POST | Захиалга илгээх |
| `/api/orders.php` | GET | Захиалгуудыг авах |

## Өнгөний палитр

| Нэр | Hex |
|-----|-----|
| Алтан (primary) | `#D4A017` |
| Алтан тод | `#F0BE45` |
| Хар (background) | `#0D0D0D` |
| Цагаан | `#FFFFFF` |

## Файлын бүтэц

```
altanbers/
├── backend/
│   ├── config/
│   │   └── database.php        # DB холболт + CORS
│   ├── api/
│   │   ├── auth.php            # Нэвтрэх/Бүртгүүлэх
│   │   ├── orders.php          # Захиалга
│   │   └── products.php        # Бүтээгдэхүүн
│   ├── uploads/                # Хуулагдсан файлууд
│   └── database.sql            # SQL схем
│
└── frontend/
    ├── src/
    │   ├── components/
    │   │   ├── Navbar.jsx/.css
    │   │   └── Footer.jsx/.css
    │   ├── pages/
    │   │   ├── Home.jsx/.css
    │   │   ├── About.jsx/.css
    │   │   ├── Products.jsx/.css
    │   │   ├── Order.jsx/.css
    │   │   └── Login.jsx/.css
    │   ├── AuthContext.jsx      # Нэвтрэлтийн state
    │   ├── App.jsx              # Router
    │   ├── main.jsx
    │   └── index.css
    ├── index.html
    ├── package.json
    └── vite.config.js
```

## Хөгжүүлэх

```bash
# Frontend dev server
cd frontend && npm run dev

# Production build
cd frontend && npm run build
```

Build хийсний дараа `frontend/dist` фолдерийг XAMPP-н `htdocs/altanbers/public` руу хуулна.
